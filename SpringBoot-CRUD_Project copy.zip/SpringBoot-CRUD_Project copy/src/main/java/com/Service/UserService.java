package com.Service;

import java.util.List;

import com.DTO.DTOController;
import com.Entity.User;

public interface UserService {

	void registerInService(User user);

	List<User> getAllUsers();

	DTOController getUserbyid(int id);

	void delUser(int id);
	

}
