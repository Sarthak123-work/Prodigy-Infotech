package com.Service;
import java.util.List;
import java.util.Optional;

import org.apache.commons.logging.Log;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.UserDao;
import com.DTO.DTOController;
import com.Entity.User;
import com.ExceptionHandling.UserNotExistsException;
import com.Repo.UserRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserServiceIMPL implements UserService{
	
	@Autowired
	private UserDao dao;
	
	@Autowired
	private UserRepo ur;

	@Override
	public void registerInService(User user) {
		
		log.info("Service layer:-"+user);
		dao.registerinDAO(user);
		
		
	}

	@Override
	public List<User> getAllUsers() {
		
		return dao.getAllUsers();
	}

	@Override
	public DTOController getUserbyid(int id) {
		log.info("In Service Layer");
//		User user =  dao.getUserbyId(id);
		
		Optional<User> user = ur.findById(id);
		
		if(user==null) {
			throw new UserNotExistsException("This User not exists");
			
		}
		
			log.info("User Exists"+user);
			
//			DTOController dtr = new DTOController();
//			dtr.setUname(user.getUname());
//			dtr.setUaddress(user.getUaddress());
			
			ModelMapper mm = new ModelMapper();
			DTOController dtr=mm.map(user, DTOController.class);

			return dtr;
		
	}

	@Override
	public void delUser(int id) {
		log.info("In Service layer for Deleting");
		dao.delUser(id);
	}

}
