package com.ExceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
	
	@ExceptionHandler(value=NullPointerException.class)
	public ResponseEntity NullpointerException(Exception ex) {
		log.error("Null Values");
		return new ResponseEntity("Exception Occured",HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value=UserNotExistsException.class)
	public ResponseEntity handleUserNotExistsException(Exception msg) {
		log.error("User Not Exists");
		log.error("This is the Message"+msg);
		return new ResponseEntity(msg.getMessage(),HttpStatus.BAD_REQUEST);
	}
	
}
