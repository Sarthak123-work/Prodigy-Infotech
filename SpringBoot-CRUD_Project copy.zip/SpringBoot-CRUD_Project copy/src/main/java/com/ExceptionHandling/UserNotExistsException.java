package com.ExceptionHandling;

public class UserNotExistsException extends RuntimeException {
	
	public UserNotExistsException(String msg) {
		super(msg);
	}

}
