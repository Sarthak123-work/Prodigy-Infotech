package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.DTO.DTOController;
import com.Entity.User;
import com.Service.UserService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/user/action")
public class UserConroller {
	
	@Autowired
	private UserService us;
	
	@RequestMapping("/registerUser")
	public User registerUser(@RequestBody User user) {
		log.info("User is"+user);
		
		us.registerInService(user);
		
		return user;
	}

	@RequestMapping("/getUser")
	public List<User> getAllUsers(){
		log.info("Fetching User");
		return us.getAllUsers();
	}
	
	
	@GetMapping("/getUserbyId/{id}")
	public ResponseEntity Userbyid(@PathVariable int id) {
		log.info("Getting User by id:");
		DTOController user = us.getUserbyid(id);
		
//		user=null;
//		System.out.println(user.toString());
		if(user==null) {
			return new ResponseEntity("User Not Exists",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity("User Exists",HttpStatus.OK);
	}
	
	@DeleteMapping("/delUser/{id}")
	public void delUser(@PathVariable int id) {
		log.info("Deleting User by id");
		us.delUser(id);
	}
}
