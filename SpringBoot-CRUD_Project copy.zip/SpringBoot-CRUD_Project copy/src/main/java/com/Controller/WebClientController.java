package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
@RequestMapping("/web")
public class WebClientController {
	
	@Autowired
	private JavaMailSender js;
	
	@GetMapping("/getData")
	public ResponseEntity<?> getData(){
		
		String url =  "http://localhost:1357/register";
		
		WebClient client = WebClient.create();
		
		return new ResponseEntity("data", HttpStatus.OK);
		
		
	}
	
	
	@PostMapping("/sms")
	public void sendMail() {
		
		SimpleMailMessage sms = new SimpleMailMessage();
		sms.setTo("sarthakjagtap01@gmail.com");
		sms.setSubject("For Practice Purpose");
		sms.setText("Hi how are you?");
		
		js.send(sms);
	}
	
	
	

}
