package com.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DTOController {
	
	@JsonProperty(value = "user_name")
	private String uname;
	
	@JsonProperty(value = "user_address")
	private String uaddress;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUaddress() {
		return uaddress;
	}

	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}

	@Override
	public String toString() {
		return "DTOController [uname=" + uname + ", uaddress=" + uaddress + "]";
	}
	
	

}
