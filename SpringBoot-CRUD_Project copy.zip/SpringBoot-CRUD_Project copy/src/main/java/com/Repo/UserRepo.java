package com.Repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.Entity.User;

public interface UserRepo extends CrudRepository<User, Integer>{
	
	public List<User> findByUname(String uname);
	
	public List<User> findByUage(int age);
	
	public List<User> findByUnameAndUage(String uname,int age);

	public User findByUnameLike(String param);
}
