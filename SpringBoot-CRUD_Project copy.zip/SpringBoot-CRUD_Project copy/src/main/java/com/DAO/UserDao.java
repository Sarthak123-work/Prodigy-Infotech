package com.DAO;

import java.util.List;

import com.Entity.User;

public interface UserDao {

	void registerinDAO(User user);

	List<User> getAllUsers();

	User getUserbyId(int id);

	void delUser(int id);

}
