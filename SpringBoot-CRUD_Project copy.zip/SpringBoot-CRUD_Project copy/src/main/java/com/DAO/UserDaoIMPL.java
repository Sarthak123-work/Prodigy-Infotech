package com.DAO;

import java.util.List;

import org.hibernate.Session;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.User;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class UserDaoIMPL implements UserDao{
	
	@Autowired
	private SessionFactory sf;

	@Override
	public void registerinDAO(User user) {
		log.info("DAO layer:-"+user);
		Session s = sf.openSession();
		s.save(user);
		s.beginTransaction().commit();
		
		log.info("User Added");
		
		
	}

	@Override
	public List<User> getAllUsers() {
		Session s = sf.openSession();
		List<User> ul = s.createQuery("from User", User.class).list();
		return ul;
	}

	@Override
	public User getUserbyId(int id) {
		Session s = sf.openSession();
		
		User u = s.get(User.class, id);
		
		return u;
	}

	@Override
	public void delUser(int id) {
	    Session s = sf.openSession();
	    User u = s.get(User.class, id); // Fetch entity by ID
	    
	    if (u != null) {
	        s.beginTransaction();
	        s.delete(u); // ✅ Pass the entity, not the ID
	        s.getTransaction().commit();
	        log.info("User deleted successfully with ID: " + id);
	    } else {
	        log.warn("User with ID " + id + " not found.");
	    }
	    
	    s.close();
	}

	
	
	
	

}
