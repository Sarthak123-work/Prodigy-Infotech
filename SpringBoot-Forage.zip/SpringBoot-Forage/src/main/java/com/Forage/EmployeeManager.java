package com.Forage;

import org.springframework.stereotype.Service;


@Service
public class EmployeeManager {
    private Employees employees = new Employees();

    public Employees getAllEmployees() {
        return employees;
    }

    public void addEmployee(Employee employee) {
        employees.addEmployee(employee);
    }
    
}

	
