package com.Forage;

import java.util.ArrayList;
import java.util.List;

public class Employees {

	private List<Employee> emplist;

	
	public Employees() {
		this.emplist = new ArrayList<>();
	}

	public List<Employee> getList() {
		return emplist;
	}

	public List<Employee> getEmplist() {
		return emplist;
	}

	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}

	public void addEmployee(Employee e) {
		emplist.add(e);  
	}
}
