//package com.testing;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.when;
//
//import com.example.demo.Employee;
//import com.example.demo.EmployeeManager;
//import com.example.demo.EmployeeRepository;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//@ExtendWith(MockitoExtension.class)
//public class EmployeeManagerTest {
//
//    @InjectMocks
//    private EmployeeManager manager;
//
//    @Mock
//    private EmployeeRepository repo;
//
//    @Test
//    void testAddEmployee() {
//        Employee emp = new Employee(1, "Alex", "HR");
//        when(repo.save(emp)).thenReturn(emp);
//
//        Employee result = manager.addEmployee(emp);
//
//        assertEquals("Alex", result.getName());
//        assertEquals("HR", result.getDept());
//    }
//}
