//package com.testing;
//
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
//
//import com.example.demo.Employee;
//import com.example.demo.EmployeeController;
//import com.example.demo.EmployeeManager;
//
//import java.util.Collections;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.MediaType;
//import org.springframework.test.web.servlet.MockMvc;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@WebMvcTest(EmployeeController.class)
//public class EmployeeControllerTest {
//
//    @Autowired
//    private MockMvc mockMvc;
//
//    @MockBean
//    private EmployeeManager manager;
//
//    @Autowired
//    private ObjectMapper objectMapper;
//
//    @Test
//    void testAddEmployee() throws Exception {
//        Employee emp = new Employee(1, "Alex", "HR");
//        when(manager.addEmployee(emp)).thenReturn(emp);
//
//        mockMvc.perform(post("/addEmployee")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(objectMapper.writeValueAsString(emp)))
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$.name").value("Alex"));
//    }
//
//    @Test
//    void testGetEmployees() throws Exception {
//        Employee emp = new Employee(1, "Alex", "HR");
//        when(manager.getAllEmployees()).thenReturn(Collections.singletonList(emp));
//
//        mockMvc.perform(get("/getEmployees"))
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$[0].name").value("Alex"));
//    }
//}
