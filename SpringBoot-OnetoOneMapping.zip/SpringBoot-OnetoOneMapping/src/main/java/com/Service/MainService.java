package com.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DTO.AdharDTO;
import com.Entity.Adhar;
import com.Entity.Person;
import com.Repo.AdharRepository;
import com.Repo.PersonRepository;

@Service
public class MainService {

	@Autowired
	private PersonRepository pr;
	
	@Autowired
	private AdharRepository ar;
	
	
	public Person savePerson(Person p) {
        return pr.save(p); // this saves to D
    }


	public List<Person> getOnlyPerson(Person p) {
		List<Person> pf=pr.findAll();
		return pf;
		
	}
	


	public String linkAdharToPerson(Adhar adhar, long pid) {
		Person person = pr.findById(pid).orElse(null);
		
		if(person==null) {
			return "person with "+pid+ " not found in record";
		}
		adhar.setPerson(person);
		ar.save(adhar);
		return "Adhar added with Pid:"+pid;
	}


	public List<Adhar> getAdhar(Adhar adhar) {
		List<Adhar> a=ar.findAll();
		return a;
		
	}


	public List<AdharDTO> getAdharOnly() {
		List<Adhar> a= ar.findAll();
		List<AdharDTO> adtList=new ArrayList<AdharDTO>();
		for(Adhar i:a) {
			AdharDTO adt = new AdharDTO(i.getAid(),i.getAdharNumber());
			adtList.add(adt);
		}
		return adtList;
	}


	public String updatePerson(long pid, Person person) {
		Optional<Person> existing=pr.findById(pid);
		
		if(existing.isPresent()) {
			Person person1 = existing.get();
			person1.setPname(person.getPname());
	        person1.setPaddress(person.getPaddress());
	        pr.save(person1);
	        return "Person with ID " + pid + " updated successfully.";
	    } else {
	        return "Person with ID " + pid + " not found in the database.";
	    }
	}


	public String updateAdhar(long pid, Adhar adhar) {
		Optional<Person> ex2=pr.findById(pid);
		
		if(ex2.isPresent()) {
			Person p2=ex2.get();
			
			 Adhar existingAdhar = ar.findByPerson(p2);
			 if(existingAdhar!=null) {
				 existingAdhar.setAdharNumber(adhar.getAdharNumber());
				 ar.save(existingAdhar);
				 return "Aadhar updated for person ID " + pid;
			 }
			 else {
				 adhar.setPerson(p2);
				 ar.save(adhar);
			 }

		}
		else {
			return "Person with pid "+pid+" not found in Database";
		}
		return null;
	}


	public String deletePerson(long pid) {
		Optional<Person> personOpt = pr.findById(pid);

	    if (personOpt.isPresent()) {
	        Person person = personOpt.get();

	        // Delete Adhar first (to avoid foreign key constraint)
	        Adhar adhar = ar.findByPerson(person);
	        if (adhar != null) {
	            ar.delete(adhar);
	        }

	        // Now delete Person
	        pr.delete(person);
	        return "Deleted Person with ID: " + pid;
	    } else {
	        return "Person with ID: " + pid + " not found.";
	    }
		
	}


	public String deleteAdhar(long pid) {
		Optional<Person> personOpt = pr.findById(pid);

	    if (personOpt.isPresent()) {
	        Person person = personOpt.get();
	        Adhar adhar = ar.findByPerson(person);

	        if (adhar != null) {
	            ar.delete(adhar);
	            return "Deleted Adhar linked to Person ID: " + pid;
	        } else {
	            return "No Adhar found for Person ID: " + pid;
	        }
	    } else {
	        return "Person with ID: " + pid + " not found.";
	    }
	}
	
	

}
