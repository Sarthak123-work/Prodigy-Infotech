package com.Controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.DTO.AdharDTO;
import com.Entity.Adhar;
import com.Entity.Person;
import com.Service.MainService;
import com.sun.org.slf4j.internal.LoggerFactory;

import ch.qos.logback.classic.Logger;
import sun.util.logging.resources.logging;

@RestController
public class MappingController {
	
	@Autowired
	private MainService ms;
	
	@PostMapping("/savePerson")
	public ResponseEntity<?> addPersonOnly(@RequestBody Person p) {
        Person saved = ms.savePerson(p);
        return new ResponseEntity<>("Person Added",HttpStatus.OK); // Return saved person as JSON
    }
	
	@GetMapping("/getOnlyPerson")
	public ResponseEntity<?> getPerson(@RequestBody Person p){
		List<Person> pr=ms.getOnlyPerson(p);
		return new ResponseEntity<>(pr,HttpStatus.OK); // Return
		
	}
	
	@PostMapping("/addAdharbyPid/{pid}")
	public ResponseEntity<?> addAdharByPid(@RequestBody Adhar adhar, @PathVariable long pid) {
	    String result = ms.linkAdharToPerson(adhar, pid);
	    return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
	@GetMapping("/getAdhar")
	public ResponseEntity<?> getAdhar(@RequestBody Adhar adhar){
		List<Adhar> alist=ms.getAdhar(adhar);
		return new ResponseEntity<>(alist,HttpStatus.OK);
		
	}
	
	@GetMapping("/getAdharOnly")
	public ResponseEntity<?> getOnlyAdhar(@RequestBody Adhar adhar){
		List<AdharDTO> ad=ms.getAdharOnly();
		return new ResponseEntity<>(ad,HttpStatus.OK);
	}
	
	@PostMapping("/updatePersonOnly/{pid}")
	public ResponseEntity<?> updatePerson(@PathVariable long pid,@RequestBody Person person) {
		String responce=ms.updatePerson(pid,person);
		return new ResponseEntity<>(responce,HttpStatus.OK);
	}

	@PostMapping("/updateAdharbyPid/{pid}")
	public ResponseEntity<?> updateAdharbyPid(@PathVariable long pid,@RequestBody Adhar adhar) {
		String responce2 = ms.updateAdhar(pid,adhar);
		return new ResponseEntity<>(responce2,HttpStatus.OK);
	}
	
	@DeleteMapping("/deletePerson/{pid}")
	public ResponseEntity<?> deletePerson(@PathVariable long pid){
		String responce3=ms.deletePerson(pid);
		return new ResponseEntity<>(responce3,HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteAdhar/{pid}")
	public ResponseEntity<?> deleteAdhar(@PathVariable long pid){
		String responce4=ms.deleteAdhar(pid);
		return new ResponseEntity<>(responce4,HttpStatus.OK);
	}


}
