package com.DTO;

public class AdharDTO {
	private int aid;
	private String adharNumber;

	public AdharDTO(int aid, String adharNumber) {
		this.aid = aid;
		this.adharNumber = adharNumber;
	}

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getAdharNumber() {
		return adharNumber;
	}

	public void setAdharNumber(String adharNumber) {
		this.adharNumber = adharNumber;
	}

	
}
