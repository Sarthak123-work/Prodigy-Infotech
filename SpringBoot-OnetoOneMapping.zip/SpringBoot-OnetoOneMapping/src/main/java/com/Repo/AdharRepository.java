package com.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.Adhar;
import com.Entity.Person;

public interface AdharRepository extends JpaRepository<Adhar, Long>{
	Adhar findByPerson(Person person);

}
