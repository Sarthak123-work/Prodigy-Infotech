package com.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.Person;

public interface PersonRepository extends JpaRepository<Person, Long>{

}
