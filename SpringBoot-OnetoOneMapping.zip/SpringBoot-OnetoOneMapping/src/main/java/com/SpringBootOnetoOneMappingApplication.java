package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOnetoOneMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOnetoOneMappingApplication.class, args);
	}

}
